unzip taskmanager_app.zip
mkdir /var/www/html/taskmanager_app
cd taskmanager_app/dist/taskmanager_app
cp -r * /var/www/html/taskmanager_app
